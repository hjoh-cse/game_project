import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class GameNotes extends JPanel{		//게임 유의사항을 보여주는 패널

    private MainFrame mainFrame;

    private JButton gameGo_btn;

    public GameNotes(MainFrame mainFrame) {
        this.mainFrame = mainFrame;

        this.setBackground(Color.darkGray);		//배경색
        this.setLayout(null);			//패널의 배치관리자 지정하지 않도록 설정

        gameGo_btn = new JButton("Game Go");
        this.add(gameGo_btn);	//현재 패널에 버튼 추가

        JLabel titleLabel = new JLabel("< Game Notice >");
        titleLabel.setForeground(Color.RED);	//텍스트 색상
        titleLabel.setFont(new Font("궁서", Font.BOLD, 40));	//글꼴, 굵게, 크기
        titleLabel.setBounds(135, 66, 380, 40);		//titleLabel의 x,y,width,height
        this.add(titleLabel);	//현재패널에 titleLabel 레이블 추가

        JLabel contents1 = new JLabel("* 자동차를 피해서 지나갈 것");
        contents1.setForeground(Color.WHITE);	//텍스트 색상
        contents1.setFont(new Font("굴림", Font.PLAIN, 20));	//글꼴, 굵게, 크기
        contents1.setBounds(190, 180, 400, 40);		//contents1의 x,y,width,height
        this.add(contents1);	//현재패널에 contents1 레이블 추가

        JLabel contents2 = new JLabel("* 자동차에 치이지 말 것");
        contents2.setForeground(Color.WHITE);	//텍스트 색상
        contents2.setFont(new Font("굴림", Font.PLAIN, 20));	//글꼴, 일반 스타일, 크기
        contents2.setBounds(190, 280, 400, 40);		//contents2의 x,y,width,height
        this.add(contents2);	//현재패널에 contents1 레이블 추가

        // 현재 화면의 크기를 얻는다.
        Dimension frameSize = getSize();

        Toolkit kit = Toolkit.getDefaultToolkit();
        Dimension screenSize = kit.getScreenSize();
        setLocation((screenSize.width - frameSize.width) / 2,
                (screenSize.height - frameSize.height) / 2); // 화면 중앙에 띄우기

        gameGo_btn.setBounds(250, 414, 120, 30); //버튼의 크기와 위치를 지정(x,y,width,height)

        setVisible(true);	//현재패널을 화면에 보이도록 설정

        gameGo_btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.gameNotesToRoadCrossingGame();	//RoadCrossingGame 화면으로 전환
            }
        });

    }
}