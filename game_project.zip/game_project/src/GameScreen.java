import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Timer;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class GameScreen extends JPanel {	//GameScreen는 첫 화면을 보여줌

    MainFrame mainFrame;

    private JButton notice_btn;		//버튼
    private int happyFaceX = 300;	//happyFace x좌표
    private int happyFaceY = 230;	//happyFace y좌표
    private final int HAPPY_FACE_SIZE = 50;
    private final int MOVE_AMOUNT = 5; // happyFace가 수평으로 이동하는 거리 (이동거리)
    private Timer timer;

    public GameScreen(MainFrame mainFrame) {	//생성자 -> MainFrame 클래스의 인스턴스를 받아와서 mainFrame 변수에 할당

        this.mainFrame = mainFrame;

        setSize(650, 480);		//현재 객체의 크기


        this.setBackground(Color.BLACK);		//배경색
        this.setLayout(null); 	// 패널의 배치관리자를 지정하지 않도록 설정

        notice_btn = new JButton("Game Notice");
        this.add(notice_btn); // 패널에 "Game Notice"버튼 추가

        JLabel titleLabel = new JLabel("Miju's Road Crossing Game");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 32));		//글꼴,굵게&이탤릭체,크기
        // setBounds()메소드를 통해 버튼의 위치와 크기를 지정
        titleLabel.setBounds(89, 78, 380, 40); // titleLabel의 x,y,width,height
        this.add(titleLabel);	//현재패널에 titleLabel 레이블 추가

        // 현재 화면의 크기를 얻는다.
        Dimension frameSize = getSize();

        Toolkit kit = Toolkit.getDefaultToolkit();
        Dimension screenSize = kit.getScreenSize();		//화면의 크기정보를 얻어옴
        setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2); // 화면 중앙에 띄우기

        notice_btn.setBounds(425, 380, 117, 30); // notice_btn의 x,y,width,height

        setVisible(true); // 창이 화면에 보임

        timer = new Timer(28, new ActionListener() { // 28밀리초마다 지속적
            @Override
            public void actionPerformed(ActionEvent e) {
                moveHappyFace(); // happyFace의 움직임
                repaint(); // 이미지의 업데이트된 위치를 표시하도록 패널을 다시 칠하기
            }
        });

        timer.start(); // 타이머 시작

        notice_btn.addActionListener(new ActionListener() { // 버튼이 눌렸을때
            @Override
            public void actionPerformed(ActionEvent e) {
                //new GameNotes();//TODO 메소드로 바꾸기
                mainFrame.gameScreenToGameNotes();	//GameNotes로 전환
                timer.stop(); // 타이머 멈춤
                setVisible(false); //현재 패널을 화면에 안보임
            }
        });

    }

    private void drawHappyFace(Graphics g) { // happyFace 이미지를 그림

        ImageIcon happyFaceIcon = new ImageIcon("src/happyFace.gif");
        Image image = happyFaceIcon.getImage();
        g.drawImage(image, happyFaceX, happyFaceY, HAPPY_FACE_SIZE, HAPPY_FACE_SIZE, null);

    }

    private void moveHappyFace() { // happyFace 이미지의 움직임
        happyFaceX += MOVE_AMOUNT;	//happyFaceX 값을 MOVE_AMOUNT만큼 증가시킴
        if (happyFaceX >= getWidth()) { 	//이미지가 화면을 넘어가면
            happyFaceX = -HAPPY_FACE_SIZE;	//happyFaceX값을 -HAPPY_FACE_SIZE로 설정하여 왼쪽 끝으로 다시 이동시킴
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawHappyFace(g);	//이미지를 그림
    }
}