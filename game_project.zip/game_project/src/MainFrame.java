import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
	
    GameScreen gameScreen;
    GameNotes gameNotes;
    RoadCrossingGame roadCrossingGame;
    
    public MainFrame(){

        gameScreen = new GameScreen(this);	//초기화
        gameNotes = new GameNotes(this);

        this.setSize(650, 480);		//현재 객체의 창의 크기 설정

        //this.setTitle("RoadCrossingGame");
        setLocationRelativeTo(null);	//창을 화면 중앙에 배치
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(new BorderLayout());

        setUndecorated(true);	//창의 장식 없앰
        setResizable(false);	//창 크기 조정 설정

        this.getContentPane().add(gameScreen); 	//현재 창의 컨텐츠 영역에 gameScreen을 추가

        setVisible(true);		//창 보여주기
    }


    public static void main(String[] args) {		//메인
        MainFrame mainFrame = new MainFrame();
    }

    public void gameScreenToGameNotes(){	//gameScreen을 gameNotes로 교체하는 메소드
        this.remove(gameScreen);	//현재창에서 'gameScreen'컴포넌트 제거
        this.getContentPane().add(gameNotes);	//현재 창의 컨텐츠 영역에 gameNotes를 추가
        revalidate();	//컨테이너의 레이아웃을 다시 계산하고 구성 요소를 재배치
        repaint();	//컨테이너와 그 안의 구성 요소들을 다시 그림
    }
    
    public void gameNotesToRoadCrossingGame(){	//gameNotes를 닫고, RoadCrossingGame을 실행하는 메소드
        
        this.dispose();		//현재 창 닫기
        new RoadCrossingGame();		//새로운 게임 실행
    }
    
    public void recreateFrame() {	//창 다시 생성
        this.dispose();				//현재 창 닫기
        setUndecorated(false);		//창 장식을 되돌려 복구
        this.setSize(600, 700);		//창 크기
        setLocationRelativeTo(null);	//창을 화면 중앙에 배치
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

}