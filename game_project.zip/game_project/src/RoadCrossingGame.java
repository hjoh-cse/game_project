import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

public class RoadCrossingGame { // 게임화면

	private JFrame frame;
	private Timer timer;
	private Player player; // 사용자
	private Car[] cars; // Car:자료형, cars:객체
	private long startTime = 0; // 게임 시작시간 0으로 초기화
	private long endTime = 0; // 게임 종료시간 0으로 초기화

	private static final int FRAME_WIDTH = 600; // 프레임의 가로
	private static final int FRAME_HEIGHT = 700; // 프레임의 세로
	private static final int PLAYER_HAPPY_FACE_SIZE = 33; // 해피페이스 크기
	private static final int CAR_WIDTH = 100; // 차의 가로
	private static final int CAR_HEIGHT = 50; // 차의 세로
	private static final int MOVE_AMOUNT = 10; // 이동거리

	public RoadCrossingGame() { // 생성자

		frame = new JFrame("Miju's Road Crossing Game"); // 창 제목
		frame.setSize(FRAME_WIDTH, FRAME_HEIGHT); // 프레임의 크기
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null); // 화면 중앙에 프레임 맞춤, 프레임의 크기조정은 불가능
		frame.setResizable(false); // 프레임 크기 조정 비활성화

		player = new Player(FRAME_WIDTH / 2 - PLAYER_HAPPY_FACE_SIZE / 2, FRAME_HEIGHT - PLAYER_HAPPY_FACE_SIZE - 47,
				PLAYER_HAPPY_FACE_SIZE);

		cars = new Car[5]; // 크기가 5인 Car 객체 배열 만들기

		// x좌표를 -로 설정한 이유 : 프레임밖에서 시작하게 하기위해
		// Car의 x좌표, y좌표, 너비, 높이
		cars[0] = new Car(-108, FRAME_HEIGHT - 220, CAR_WIDTH, CAR_HEIGHT, new ImageIcon("src/자동차1.png"), 3);
		cars[1] = new Car(-111, FRAME_HEIGHT - 320, CAR_WIDTH, CAR_HEIGHT, new ImageIcon("src/자동차2.png"), 10);
		cars[2] = new Car(-120, FRAME_HEIGHT - 568, CAR_WIDTH, CAR_HEIGHT, new ImageIcon("src/자동차3.png"), 17);
		cars[3] = new Car(-148, FRAME_HEIGHT - 486, CAR_WIDTH, CAR_HEIGHT, new ImageIcon("src/자동차4.png"), 7);
		cars[4] = new Car(-153, FRAME_HEIGHT - 420, CAR_WIDTH, CAR_HEIGHT, new ImageIcon("src/자동차5.png"), 20);

		// KeyAdapter : KeyListener 인터페이스를 구현하는 편의 클래스
		frame.addKeyListener(new KeyAdapter() { // 키 이벤트
			@Override
			public void keyPressed(KeyEvent e) { // 키를 눌렀을 때
				movePlayer(e);

			}

			public void keyReleased(KeyEvent arg0) {
			} // 키 누르기를 멈췄을 때
			// keyReleased : KeyAdapter를 확장하는 익명 내부 클래스의 일부
		});

		frame.add(new GamePanel()); // 프레임에 추가

		// 타이머 -> 게임상태를 업데이트하고 프레임을 다시 그리기위해 일정한 간격으로 updateGame() 메소드를 트리거하는데 사용
		timer = new Timer(30, new ActionListener() { // Timer가 30밀리초 지연으로 설정
			public void actionPerformed(ActionEvent e) {
				updateGame();
			}
		});

		frame.requestFocus(); // 구성 요소에 대한 키보드 포커스를 요청하는 데 사용
		frame.setFocusable(true); // 키보드 포커스를 수신하여 키보드 입력 이벤트를 수신하고 처리할 수 있도록 하는 데 사용
		frame.setVisible(true); // 프레임에 보여줌
	}

	private void movePlayer(KeyEvent e) { // 키보드 입력을 처리하고 이에따라 Player의 위치를 업데이트함
		int keyCode = e.getKeyCode();
		int x = player.getX();
		int y = player.getY();

		if (keyCode == KeyEvent.VK_LEFT && x > 0) { // 왼쪽 화살표키를 눌렀을때
			player.setX(x - MOVE_AMOUNT);
		} else if (keyCode == KeyEvent.VK_RIGHT && x < FRAME_WIDTH - PLAYER_HAPPY_FACE_SIZE) { // 오른쪽 화살표키를 눌렀을때
			player.setX(x + MOVE_AMOUNT);
		} else if (keyCode == KeyEvent.VK_UP && y > 0) { // 위쪽 화살표키를 눌렀을때
			player.setY(y - MOVE_AMOUNT);
		} else if (keyCode == KeyEvent.VK_DOWN && y < FRAME_HEIGHT - PLAYER_HAPPY_FACE_SIZE) { // 아래쪽 화살표키를 눌렀을때
			player.setY(y + MOVE_AMOUNT);
		}

		player.repaint(); // 다시 그림
	}

	private void updateGame() { // 게임 상태 업데이트

		player.update(); // 플레이어 위치 업데이트

		for (Car car : cars) {
			car.update(); // 자동차의 위치 업데이트

			if (car.intersects(player)) { // car가 player와 교차하는지
				timer.stop(); // 타이머를 멈추고 게임을 일시정지
				player.setCollided(true); // player가 car와 충돌했음을 나타냄
				frame.repaint(); // 게임 패널을 업데이트하고 충돌 후 새 상태를 표시

				JOptionPane.showMessageDialog(frame, "Game Over!", "Miju's Street Crossing Game",
						JOptionPane.INFORMATION_MESSAGE);
				frame.dispose(); // 프레임을 폐기하고 게임창을 닫음
				break; // 루프 종료하는데 사용
			} else if (player.getY() <= 26) { // player가 도로를 성공적으로 건넜음을 나타냄
				endTime = System.currentTimeMillis(); // endTime을 기록
				timer.stop(); // 타이머를 멈추고 게임을 일시정지
				player.setCollided(false); // player가 car와 충돌하지 않았음을 나타냄
				frame.repaint();

				long timeTaken = (endTime - startTime) / 1000; // 길을 건너는 데 걸리는 시간

				JOptionPane.showMessageDialog(frame,
						"	Congratulations!\n" + "You crossed the road in " + timeTaken + "seconds!",
						"Miju's Road Crossing Game", JOptionPane.INFORMATION_MESSAGE);
				frame.dispose(); // 프레임을 폐기하고 게임창을 닫음
				break; // 루프 종료하는데 사용
			}

		}

		frame.repaint();
	}

	public void startGame() { // 시작화면에 보임
		frame.setVisible(true);

	}

	class GamePanel extends JPanel {
		private JButton startButton; // 시작버튼
		private JButton stopButton; // 중지버튼
		private JButton exitButton; // 종료버튼
		private Image backgroundImg; // 배경이미지

		public GamePanel() {
			startButton = new JButton("start");
			startButton.addActionListener(new ActionListener() { // 시작버튼을 눌렀을 때
				public void actionPerformed(ActionEvent e) {
					startTime = System.currentTimeMillis(); //
					timer.start(); // 타이머 실행, 게임 실행
					
				}
			});

			stopButton = new JButton("stop");
			stopButton.addActionListener(new ActionListener() { // 중지버튼을 눌렀을 때
				public void actionPerformed(ActionEvent e) {
					timer.stop(); // 타이머 중지, 게임 중지
					
				}
			});

			exitButton = new JButton("exit");
			exitButton.addActionListener(new ActionListener() { // 종료버튼을 눌렀을 때
				public void actionPerformed(ActionEvent e) {
					frame.dispose(); // 사라짐
					
				}
			});

			// 버튼에는 포커스할 수 없게 만든다
			startButton.setFocusable(false);
			stopButton.setFocusable(false);
			exitButton.setFocusable(false);

			// 버튼추가
			add(startButton);
			add(stopButton);
			add(exitButton);

			backgroundImg = new ImageIcon("src/도로 그림.png").getImage();
		}

		@Override
		protected void paintComponent(Graphics g) { // paintComponent 메소드 -> 사용자 지정 구성요소를 그리는 일을 담당
			super.paintComponent(g);

			g.drawImage(backgroundImg, 0, 0, getWidth(), getHeight(), this); // 배경이미지, 패널에서 이미지가 그려질 왼쪽 상단위치(0,0), 이미지의
																				// 폭, 이미지의 높이, 현재 패널
			player.draw(g); // player 그리기
			for (Car car : cars) {
				car.draw(g); // car 그리기
			}
		}
	}

	class Player extends JComponent { // Player
		private int x;
		private int y;
		private int size;

		private boolean collided; // player가 car와 충돌했는가

		public Player(int x, int y, int size) { // 생성자
			this.x = x;
			this.y = y;
			this.size = size;
			this.collided = false; // 충돌하지 않았음
		}

		public void setCollided(boolean collided) { // 다른부분에서 palyer의 '충돌됨'상태를 업데이트할 수 있음
			this.collided = collided;
		}

		public int getX() { // player x좌표 반환
			return x;
		}

		public int getY() { // player y좌표 반환
			return y;
		}

		public void setX(int x) { // player x좌표 업데이트
			this.x = x;
		}

		public void setY(int y) { // player y좌표 업데이트
			this.y = y;
		}

		public Rectangle getBounds() { // 플레이어의 경게상자를 나타냄
			return new Rectangle(x, y, size, size);
		}

		public void update() {
			// Perform any updates if needed
		}

		public void draw(Graphics g) {
			ImageIcon icon;
			if (collided) { // player가 충돌했을 때
				icon = new ImageIcon("src/sadFace.png");
			} else { // player가 충돌하지 않았을 때
				icon = new ImageIcon("src/happyFace.gif");
			}
			g.drawImage(icon.getImage(), x, y, size, size, null);
		}
	}

	class Car { // Car

		private int x;
		private int y;
		private int width;
		private int height;
		private ImageIcon carImg;
		private int speed;

		public Car(int x, int y, int width, int height, ImageIcon carImg, int speed) {
			this.x = x;
			this.y = y;
			this.width = width;
			this.height = height;
			this.carImg = carImg;
			this.speed = speed;
		}

		public Rectangle getBounds() {
			return new Rectangle(x, y, width, height);
		}

		public void update() {
			x += (speed + 4);

			if (x > FRAME_WIDTH) { // 자동차가 화면의 오른쪽 가장자리를 넘어가면 왼쪽 가장자리로 돌아가게 만듦
				x = -width;
			}
		}

		public void draw(Graphics g) {
			g.drawImage(carImg.getImage(), x, y, width, height, null);
		}

		public boolean intersects(Player player) {
			// car의 경계상자가 player의 경계상자와 교차하면 충돌이 발생했음을 나타내는 true를 반환하고, 그렇지 않으면 false 반환
			return getBounds().intersects(player.getBounds());
		}

	}

}